<figure align="center">
  <img src="../../images/docs/current-line-blame.png" alt="Inline Blame" />
  <figcaption>Inline Blame</figcaption>
</figure>

<figure align="center">
  <img src="../../images/docs/code-lens.png" alt="Git CodeLens" />
  <figcaption>Git CodeLens</figcaption>
</figure>

<figure align="center">
  <img src="../../images/docs/hovers-current-line.png" alt="Inline Blame Hover" />
  <figcaption>Hovers</figcaption>
</figure>
