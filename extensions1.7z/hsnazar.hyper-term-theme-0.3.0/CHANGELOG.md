# Change Log
All notable changes to the "hyper-term-theme" extension will be documented in this file.

Check [Keep a Changelog](http://keepachangelog.com/) for recommendations on how to structure this file.

## [0.0.7]  
- Added C# Type coloring

## [0.0.6]
- Initial release
